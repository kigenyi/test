"use strict";
/*    JavaScript 7th Edition
      Chapter 12
      Project 12-02

      Project to convert between celsius and fahrenheit
      Author: herbert kigenyi
      Date:   12/7/2022

      Filename: project12-02.js
*/

//2.	Go to the project12-02.html file in your code editor. Add a script element to load the latest minified build of the jQuery library from the CDN on the jQuery website. Add another script element to load the contents of the project12-02.js file and defer that script until after the page is completely loaded. Study the contents and structure of the document and then close the file, saving your changes.

//3.	Go to the project12-02.js file in your code editor. Below the comment section apply the change() method to the input#cValue element, responding to changes in the Celsius input box. Within the change() method create an anonymous function that does the following:
$("input#cValue").change(function () {
      //a.	Declare the celsius variable, setting its value equal to the value of the event target. Use the val() method to get the event target’s value.
      var celsius = $("#cValue").val();
      //b.	Declare the fahrenheit variable with a value equal to 1.8 times the celsius variable’s value plus 32.
      var fahrenheit = celsius * 1.8 + 32;
      //c.	Apply the val() method to the input#fValue element, displaying the value of the fahrenheit variable. Apply the toFixed(0) method to that variable, displaying the calculate value as an integer.
      $("#fValue").val(fahrenheit.toFixed(0));
});
//4.	Apply change() method to the input#fValue element, responding to changes to the fahrenheit input box. Add the following commands to the anonymous function for the change() method:

$("input#fValue").change(function (event) {
      var fahrenheit = $("#fValue").val();
      var celsius = (fahrenheit - 32) / 1.8;
      $("input#cValue").val(celsius.toFixed(0));
});
